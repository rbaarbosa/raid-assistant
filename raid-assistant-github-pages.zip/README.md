# Raid Assistant — publicação no GitHub Pages

Este pacote contém `index.html`, a página do Raid Assistant.

## Publicar gratuitamente pelo iPhone ou computador

1. Entre em https://github.com e crie uma conta, se ainda não tiver.
2. Crie um repositório novo chamado `raid-assistant`.
3. Marque o repositório como **Public**.
4. Envie o arquivo `index.html` para a raiz do repositório (Add file → Upload files → Commit changes).
5. No repositório, abra **Settings → Pages**.
6. Em **Build and deployment**, selecione **Deploy from a branch**.
7. Escolha a branch **main** e a pasta **/(root)**; toque em **Save**.
8. Aguarde a publicação. O endereço será:
   https://SEU-USUARIO.github.io/raid-assistant/

Depois abra esse endereço no Safari do iPhone e use Compartilhar → Adicionar à Tela de Início.

Observação: a página registra dados no armazenamento local do navegador. Evite limpar os dados do Safari se quiser preservar o histórico. O painel não automatiza o Pokémon GO nem controla o iPogo.
